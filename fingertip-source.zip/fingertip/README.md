# fingertip

> 本文为第一版历史说明。当前第二版请阅读 [README-v2.md](README-v2.md)，使用 `python server.py` 启动完整功能。

A browser-based piano learning prototype in Chinese.

## Run locally

From this folder, run `python -m http.server 4173 --directory dist`, then open http://localhost:4173.

## Included

- 88 playable keys (A0–C8): 52 white and 36 black.
- Synthesized piano-like sound using the Web Audio API.
- Selected-key highlighting, staff notation, ledger lines, sharps, note names and frequencies.
- Octave notation keeps extreme notes readable (8va/15ma/22ma, 8vb/15mb).
- Three short theory topics and ten common notation symbols.
- Opening phrases of Twinkle Twinkle Little Star and Ode to Joy with pitch-by-pitch practice, reset and demonstration playback.
- Responsive layout with horizontally scrolling piano keys.

This first version checks pitch order, not rhythm, microphone input or MIDI hardware. The audio is synthesized rather than sampled from an acoustic piano. Practice phrases are pitch exercises, not complete engraved scores.

## GitHub research

- https://github.com/Tonejs/Tone.js — MIT-licensed browser audio framework; suitable for future sampled piano playback.
- https://github.com/0xfe/vexflow — MIT-licensed music notation library; suitable for future full score rendering.
- https://github.com/yasinatesim/piano-app — MIT-licensed example of an 88-key browser piano.

This prototype uses original application code; no code or audio samples were copied from those repositories. Google Fonts is optional; system fonts provide a fallback.
