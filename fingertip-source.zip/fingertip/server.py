"""Local fingertip server. Image/PDF recognition runs in a separate Audiveris process."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse, parse_qs
import json, os, re, subprocess, threading, time, uuid, zipfile, argparse

ROOT=Path(__file__).resolve().parent
RUNTIME=ROOT/'runtime'
ENGINE=RUNTIME/'audiveris'/'Audiveris'
JOBS={}
LOCK=threading.Lock()
ENGINE_SLOT=threading.Semaphore(1)
MAX_BYTES=30*1024*1024

def engine_command(source,output):
    java=ENGINE/'runtime'/'bin'/'java.exe'
    return [str(java),'-Xms256m','-Xmx3G',f'-Dorg.bytedeco.javacpp.cachedir={RUNTIME / "native"}',
            '--add-exports=java.desktop/sun.awt.image=ALL-UNNAMED','--enable-native-access=ALL-UNNAMED',
            '-Dfile.encoding=UTF-8','-cp',str(ENGINE/'app'/'*'),'Audiveris','-batch','-transcribe','-export','-output',str(output),'--',str(source)]

def recognize(job):
    with ENGINE_SLOT:
        if job['status']=='cancelled': return
        job['status']='running'; folder=job['folder']; output=folder/'result';output.mkdir(exist_ok=True)
        try:
            with (folder/'engine.log').open('wb') as log:
                process=subprocess.Popen(engine_command(job['source'],output),cwd=str(ROOT),stdout=log,stderr=subprocess.STDOUT,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
                job['process']=process
                try: process.wait(timeout=600)
                except subprocess.TimeoutExpired: process.kill();process.wait();raise RuntimeError('识谱超过 10 分钟，请裁切为较少页面后重试。')
            if job['status']=='cancelled': return
            docs=[]
            for file in sorted(output.rglob('*.mxl')):
                with zipfile.ZipFile(file) as archive:
                    choices=[n for n in archive.namelist() if n.lower().endswith(('.xml','.musicxml')) and not n.startswith('META-INF/')]
                    for name in choices:
                        if archive.getinfo(name).file_size>20*1024*1024: continue
                        xml=archive.read(name).decode('utf-8-sig')
                        if '<score-partwise' in xml:docs.append({'name':file.stem,'xml':xml})
            if not docs:
                for file in sorted(output.rglob('*.xml')):
                    if file.stat().st_size<20*1024*1024:
                        xml=file.read_text(encoding='utf-8-sig')
                        if '<score-partwise' in xml:docs.append({'name':file.stem,'xml':xml})
            if not docs:raise RuntimeError('没有识别出可导出的乐谱。请使用清晰、端正的印刷五线谱；也可对照原图手动录入。')
            job['documents']=docs;job['status']='done'
        except Exception as error:
            if job['status']!='cancelled':job['status']='error';job['error']=str(error)
        finally:job.pop('process',None)

def public_job(job):
    result={k:job[k] for k in ('id','status','error','documents') if k in job}
    logfile=job['folder']/'engine.log'
    if logfile.exists():
        content=logfile.read_text(encoding='utf-8',errors='replace')[-12000:]
        stages=re.findall(r'\b(LOAD|BINARY|SCALE|GRID|HEADERS|STEMS|HEADS|TEXTS|MEASURES|CHORDS|SYMBOLS|RHYTHMS|PAGE)\b',content)
        result['stage']=stages[-1] if stages else '正在分析谱面'
    return result

class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*args,**kwargs):super().__init__(*args,directory=str(ROOT/'dist'),**kwargs)
    def end_headers(self):
        self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');super().end_headers()
    def respond(self,value,status=200):
        body=json.dumps(value,ensure_ascii=False).encode();self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
    def valid_origin(self):
        origin=self.headers.get('Origin');host=self.headers.get('Host','')
        return host in (f'127.0.0.1:{self.server.server_port}',f'localhost:{self.server.server_port}') and (not origin or urlparse(origin).netloc==host)
    def do_GET(self):
        route=urlparse(self.path).path
        if route=='/api/health':return self.respond({'omr':(ENGINE/'runtime'/'bin'/'java.exe').exists(),'engine':'Audiveris 5.11.0','local':True})
        match=re.fullmatch(r'/api/omr/([a-f0-9]{32})',route)
        if match:
            job=JOBS.get(match[1]);return self.respond(public_job(job) if job else {'error':'任务不存在'},200 if job else 404)
        if route.startswith('/api/'):return self.respond({'error':'接口不存在'},404)
        return super().do_GET()
    def do_POST(self):
        if not self.valid_origin():return self.respond({'error':'只允许本机页面调用识谱服务。'},403)
        route=urlparse(self.path)
        cancel=re.fullmatch(r'/api/omr/([a-f0-9]{32})/cancel',route.path)
        if cancel:
            job=JOBS.get(cancel[1]);
            if not job:return self.respond({'error':'任务不存在'},404)
            job['status']='cancelled';process=job.get('process')
            if process:process.terminate()
            return self.respond({'status':'cancelled'})
        if route.path!='/api/omr':return self.respond({'error':'接口不存在'},404)
        if not (ENGINE/'runtime'/'bin'/'java.exe').exists():return self.respond({'error':'本机识谱引擎尚未安装，请运行项目的 setup_omr.py。'},503)
        length=int(self.headers.get('Content-Length','0') or 0)
        if length<=0 or length>MAX_BYTES:return self.respond({'error':'请选择 30 MB 以内的图片或 PDF。'},413)
        filename=parse_qs(route.query).get('name',['score.pdf'])[0];ext=Path(filename).suffix.lower()
        if ext not in ('.pdf','.png','.jpg','.jpeg','.tif','.tiff','.bmp'):return self.respond({'error':'支持 PDF、PNG、JPEG、TIFF 和 BMP。'},400)
        with LOCK:
            if sum(j['status'] in ('queued','running') for j in JOBS.values())>=3:return self.respond({'error':'已有识谱任务正在处理，请稍后再试。'},429)
            data=self.rfile.read(length)
            valid=data.startswith((b'%PDF',b'\x89PNG',b'\xff\xd8',b'II*\x00',b'MM\x00*',b'BM'))
            if not valid:return self.respond({'error':'文件内容与图片/PDF格式不符。'},400)
            jobid=uuid.uuid4().hex;folder=RUNTIME/'jobs'/jobid;folder.mkdir(parents=True);source=folder/('source'+ext);source.write_bytes(data)
            job={'id':jobid,'folder':folder,'source':source,'status':'queued'};JOBS[jobid]=job
            threading.Thread(target=recognize,args=(job,),daemon=True).start()
        return self.respond({'id':jobid,'status':'queued'},202)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--port',type=int,default=4182);args=parser.parse_args()
    server=ThreadingHTTPServer(('127.0.0.1',args.port),Handler)
    print(f'fingertip: http://127.0.0.1:{args.port}',flush=True)
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:
        for job in JOBS.values():
            if job.get('process'):job['process'].terminate()
        server.server_close()
