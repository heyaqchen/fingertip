import ctypes as C, pathlib, subprocess, shutil
root=pathlib.Path(__file__).resolve().parent/'runtime'
msi=C.WinDLL('msi')
HANDLE=C.c_uint
def query(db,sql):
    view=HANDLE(); status=msi.MsiDatabaseOpenViewW(db,C.c_wchar_p(sql),C.byref(view))
    if status: raise OSError(status,sql)
    if msi.MsiViewExecute(view,0): raise RuntimeError(sql)
    while True:
        rec=HANDLE(); code=msi.MsiViewFetch(view,C.byref(rec))
        if code==259: break
        if code: raise OSError(code)
        yield rec
        msi.MsiCloseHandle(rec)
    msi.MsiCloseHandle(view)
def string(rec,col):
    n=C.c_uint(32768); b=C.create_unicode_buffer(32768)
    code=msi.MsiRecordGetStringW(rec,col,b,C.byref(n))
    if code: raise OSError(code)
    return b.value
db=HANDLE(); code=msi.MsiOpenDatabaseW(C.c_wchar_p(str(root/'Audiveris-5.11.0-windows-x86_64.msi')),None,C.byref(db))
if code: raise OSError(code)
out=root/'audiveris'; out.mkdir(exist_ok=True)
flat=root/'cab-files'; flat.mkdir(exist_ok=True)
for rec in query(db,'SELECT `Name`, `Data` FROM `_Streams`'):
    name=string(rec,1)
    if not name.lower().endswith('.cab'): continue
    cab=root/pathlib.Path(name).name
    with cab.open('wb') as f:
        while True:
            b=C.create_string_buffer(1048576); n=C.c_uint(len(b))
            err=msi.MsiRecordReadStream(rec,2,b,C.byref(n))
            if err: raise OSError(err)
            if n.value==0: break
            f.write(b.raw[:n.value])
    subprocess.run(['expand.exe','-F:*',str(cab),str(flat)],check=True,stdout=subprocess.DEVNULL)
dirs={string(r,1):(string(r,2),string(r,3)) for r in query(db,'SELECT `Directory`, `Directory_Parent`, `DefaultDir` FROM `Directory`')}
components={string(r,1):string(r,2) for r in query(db,'SELECT `Component`, `Directory_` FROM `Component`')}
def folder(key):
    if not key or key not in dirs: return out
    parent,name=dirs[key]; name=name.split(':')[0].split('|')[-1]
    base=folder(parent)
    return base if name in ('.','SourceDir','TARGETDIR') else base/name
count=0
for r in query(db,'SELECT `File`, `Component_`, `FileName` FROM `File`'):
    key,component,name=[string(r,i) for i in (1,2,3)]
    dest=folder(components[component])/name.split('|')[-1]
    if not dest.resolve().is_relative_to(out.resolve()): raise ValueError('Invalid MSI path')
    src=flat/key
    if not src.exists(): src=flat/name.split('|')[-1]
    if not src.exists(): raise FileNotFoundError(key)
    dest.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(src,dest); count+=1
msi.MsiCloseHandle(db)
print('Extracted',count,'files under',out)
