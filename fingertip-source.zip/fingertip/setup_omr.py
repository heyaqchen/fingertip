"""Download official Audiveris 5.11.0 and extract a portable Windows runtime."""
from pathlib import Path
import urllib.request, subprocess, sys, os
if os.name!='nt':
    raise SystemExit('This setup supports Windows x64 only.')
root=Path(__file__).resolve().parent
runtime=root/'runtime'; runtime.mkdir(exist_ok=True)
name='Audiveris-5.11.0-windows-x86_64.msi'
destination=runtime/name
url='https://github.com/Audiveris/audiveris/releases/download/5.11.0/'+name
print('Audiveris is AGPL-3.0. Source and license: https://github.com/Audiveris/audiveris/tree/5.11.0')
if not destination.exists():
    print('Downloading official engine (~85 MB)...',flush=True)
    urllib.request.urlretrieve(url,destination)
if destination.stat().st_size!=85062430:
    raise SystemExit('Download size mismatch. Remove the incomplete MSI and retry.')
subprocess.run([sys.executable,str(root/'extract_omr.py')],check=True)
print('Ready. Run python server.py and open http://127.0.0.1:4182')
